#include<bits/stdc++.h>
using namespace std;

int value(char r)
{
    if (r == 'I')
        return 1;
    if (r == 'V')
        return 5;
    if (r == 'X')
        return 10;
    if (r == 'L')
        return 50;
    if (r == 'C')
        return 100;
    if (r == 'D')
        return 500;
    if (r == 'M')
        return 1000;

    return -1;
}

int convert_to_decimal(string &str)
{
    int res = 0;

    for (int i=0; i<str.length(); i++)
    {
        int s1 = value(str[i]);

        if (i+1 < str.length())
        {
            int s2 = value(str[i+1]);

            if (s1 >= s2)
            {
                res = res + s1;
            }
            else
            {
                res = res + s2 - s1;
                i++;
            }
        }
        else
        {
            res = res + s1;
            i++;
        }
    }
    return res;
}


int Calculate_roman(int first, int second, char operation)
{
	switch (operation)
	{
	case '+':
		return first + second;
		break;
	case '-':
		return first - second;
		break;
	case '*':
		return first * second;
		break;
	case '/':
		if (second != 0)
			return first / second;
		else
			break;
	default:
		return -1;
	}
	return -1;
}

string int_to_roman(int a)
{
    string ans;
    string M[] = {"","M","MM","MMM"};
    string C[] = {"","C","CC","CCC","CD","D","DC","DCC","DCCC","CM"};
    string X[] = {"","X","XX","XXX","XL","L","LX","LXX","LXXX","XC"};
    string I[] = {"","I","II","III","IV","V","VI","VII","VIII","IX"};
    ans = M[a/1000]+C[(a%1000)/100]+X[(a%100)/10]+I[(a%10)];
    return ans;
}
int main()
{   // variable
    string Roman_No_1, Roman_No_2;
	char operation;

	cout<<" Enter First Roman Number :: ";
    cin>>Roman_No_1;

    cout<<" Enter Second Roman Number :: ";
    cin>>Roman_No_2;

    cout<<" Enter OPeration :: ";
    cin>>operation;

   // convert roman 2 dec process and calculate

	int cal=Calculate_roman(convert_to_decimal(Roman_No_1), convert_to_decimal(Roman_No_2), operation);

   // convert  dec 2 roman

     cout<<" "<<Roman_No_1<<" "<<operation<<" "<<Roman_No_2<<" "<<"="<<" "<< int_to_roman(cal);

return 0;
}


